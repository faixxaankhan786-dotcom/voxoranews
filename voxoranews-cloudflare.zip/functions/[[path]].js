// Voxora News on Cloudflare Pages: server-renders pages from your own articles.json plus live RSS feeds.
// Each page is cached for 10 minutes, so news updates itself with no rebuilds.
const SITE = "https://voxoranews.com", NAME = "Voxora News";
const FEEDS = [ // [category, source name, feed url] - edit freely
  ["pakistan", "Dawn", "https://www.dawn.com/feeds/home"],
  ["pakistan", "The Express Tribune", "https://tribune.com.pk/feed/home"],
  ["business", "Dawn", "https://www.dawn.com/feeds/business"],
  ["sports", "Dawn", "https://www.dawn.com/feeds/sport"],
  ["world", "Dawn", "https://www.dawn.com/feeds/world"],
  ["world", "BBC News", "https://feeds.bbci.co.uk/news/world/rss.xml"],
];
const ISL = /islamabad|rawalpindi|margalla|capital territory|\bICT\b|F-?9 park/i;
const CATS = {
  pakistan: ["Pakistan", "Pakistan Live News Today", "Pakistan Live News Today: Latest Breaking Headlines | Voxora News", "Live Pakistan news today: politics, economy, security and breaking headlines from Lahore, Karachi, Islamabad, Peshawar and Quetta, refreshed through the day."],
  islamabad: ["Islamabad", "Islamabad News Today", "Islamabad News Today: Latest Updates from the Capital | Voxora News", "Islamabad news today: government, courts, parliament, traffic and city updates from the federal capital and Rawalpindi."],
  world: ["World", "World News Today", "World News Today: Global Headlines and Analysis | Voxora News", "World news today: international headlines, Middle East, South Asia, US and global affairs, updated through the day."],
  business: ["Business", "Pakistan Business and Economy News", "Business News Pakistan: Economy, PSX, Rupee and Markets | Voxora News", "Pakistan business news: economy, stock exchange (PSX), rupee, inflation, IMF and energy market updates."],
  sports: ["Sports", "Pakistan Sports News", "Sports News Pakistan: Cricket, Football and More | Voxora News", "Pakistan sports news: cricket scores, PCB updates, hockey, football and international sport."],
};
const STATIC = {
  about: ["About Voxora News", "Voxora News brings together the latest Pakistan and world headlines in one fast, readable place. We link every story to the original publisher, and our pages refresh automatically through the day."],
  privacy: ["Privacy Policy", "Voxora News does not require an account. We may use standard analytics and advertising cookies to understand traffic and improve the site. Links on this site lead to third-party publishers who have their own privacy policies. For questions, use the contact page."],
};

const esc = s => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const ent = s => s.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#0?39;|&apos;/g, "'").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&");
const txt = s => ent(ent(s).replace(/<[^>]+>/g, " ")).replace(/\s+/g, " ").trim();
const tag = (s, t) => { const m = s.match(new RegExp("<" + t + "(?:\\s[^>]*)?>([\\s\\S]*?)</" + t + ">", "i")); return m ? m[1].replace(/^\s*<!\[CDATA\[|\]\]>\s*$/g, "").trim() : ""; };
const when = d => d.getTime() ? new Intl.DateTimeFormat("en-GB", { dateStyle: "medium", timeStyle: "short", timeZone: "Asia/Karachi" }).format(d) + " PKT" : "";

function parse(xml, cat, src) {
  return (xml.match(/<item[\s>][\s\S]*?<\/item>/gi) || []).slice(0, 25).map(it => {
    const raw = tag(it, "description");
    const img = (it.match(/<(?:media:thumbnail|media:content|enclosure)[^>]*?url="(https:[^"]+)"/i) || ent(raw).match(/<img[^>]*src="(https:[^"]+)"/i) || [])[1];
    const d = new Date(tag(it, "pubDate")), desc = txt(raw);
    return { cat, src, img, title: txt(tag(it, "title")), link: txt(tag(it, "link")),
      desc: desc.length > 190 ? desc.slice(0, 187).replace(/\s\S*$/, "") + "…" : desc, date: isNaN(d) ? new Date(0) : d };
  }).filter(i => i.title && /^https?:/.test(i.link));
}

async function load(own = []) {
  const res = await Promise.allSettled(FEEDS.map(async ([cat, src, url]) => {
    const r = await fetch(url, { signal: AbortSignal.timeout(7000), headers: { "user-agent": "VoxoraNewsBot/1.0 (+https://voxoranews.com)" } });
    return parse(await r.text(), cat, src);
  }));
  const seen = new Set();
  return [...own, ...res.flatMap(r => r.status === "fulfilled" ? r.value : [])].sort((a, b) => b.date - a.date).filter(i => !seen.has(i.link) && seen.add(i.link));
}

const by = (items, c) => c === "islamabad" ? items.filter(i => i.cat === "islamabad" || (i.cat === "pakistan" && ISL.test(i.title + " " + i.desc))) : c === "pakistan" ? items.filter(i => i.cat === "pakistan" || i.cat === "islamabad") : items.filter(i => i.cat === c);
const a = i => i.own ? `<a href="${esc(i.link)}">` : `<a href="${esc(i.link)}" target="_blank" rel="noopener nofollow">`;
const pic = i => i.img ? `<img src="${esc(i.img)}" alt="${esc(i.title)}" loading="lazy" width="640" height="400">` : `<div class="ph"></div>`;
const meta = i => `<div class="meta"><b>${esc(i.src)}</b><time datetime="${i.date.toISOString()}">${when(i.date)}</time></div>`;
const row = i => `<article class="row">${a(i)}${pic(i)}</a><div><h3>${a(i)}${esc(i.title)}</a></h3><p>${esc(i.desc)}</p>${meta(i)}</div></article>`;
const card = i => `<article>${a(i)}${pic(i)}</a><h3>${a(i)}${esc(i.title)}</a></h3>${meta(i)}</article>`;
const empty = `<div class="empty"><b>Headlines are loading.</b><p>Our news sources did not respond just now. Refresh in a minute.</p></div>`;

function shell({ path, title, desc, h1, sub, body, items = [], image, extra = [] }) {
  const nav = [["/", "Home"], ["/pakistan", "Pakistan"], ["/islamabad", "Islamabad"], ["/world", "World"], ["/business", "Business"], ["/sports", "Sports"], ["/contact", "Contact"]]
    .map(([h, l]) => `<a href="${h}"${h === path ? ' class="on"' : ""}>${l}</a>`).join("");
  const ld = [{ "@context": "https://schema.org", "@type": "NewsMediaOrganization", name: NAME, url: SITE, logo: SITE + "/favicon.svg" },
    ...(items.length ? [{ "@context": "https://schema.org", "@type": "CollectionPage", name: title, url: SITE + path, mainEntity: { "@type": "ItemList", itemListElement: items.slice(0, 10).map((i, n) => ({ "@type": "ListItem", position: n + 1, url: i.link, name: i.title })) } }] : []), ...extra];
  const url = SITE + (path === "/" ? "/" : path);
  return `<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(title)}</title><meta name="description" content="${esc(desc)}"><link rel="canonical" href="${url}">
<meta name="robots" content="index,follow,max-image-preview:large"><meta property="og:type" content="website"><meta property="og:site_name" content="${NAME}">
<meta property="og:title" content="${esc(title)}"><meta property="og:description" content="${esc(desc)}"><meta property="og:url" content="${url}"><meta name="twitter:card" content="summary">${image ? `<meta property="og:image" content="${esc(image)}">` : ""}
<link rel="icon" href="/favicon.svg" type="image/svg+xml"><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Instrument+Sans:wght@400;600&family=Newsreader:opsz,wght@6..72,600;6..72,700&display=swap">
<link rel="stylesheet" href="/style.css"><script type="application/ld+json">${JSON.stringify(ld)}</script></head><body>
<div class="top"><div class="w"><span class="live">Live updates</span><span>${new Intl.DateTimeFormat("en-GB", { dateStyle: "full", timeZone: "Asia/Karachi" }).format(new Date())}</span></div></div>
<header class="w mast"><a class="logo" href="/">Voxora<span>News</span></a><span class="tag">Pakistan and world news, refreshed through the day</span></header>
<nav aria-label="Sections"><div class="w">${nav}</div></nav>
<main class="w">${h1 ? `<h1 class="pg">${esc(h1)}</h1><p class="sub">${esc(sub || "")}</p>` : ""}${body}</main>
<footer><div class="w"><div><a href="/about">About</a><a href="/contact">Contact</a><a href="/privacy">Privacy Policy</a></div>
<div>Headlines link to the original publishers. Copyright &copy; 2026 ${NAME}.</div><div class="made">Made by Faizan</div></div></footer></body></html>`;
}

function home(items) {
  if (!items.length) return shell({ path: "/", title: "Voxora News | Pakistan Live News & World Headlines", desc: "Read the latest Pakistan news, Islamabad updates, world headlines, business and sports on Voxora News.", h1: "Pakistan Live News and World Headlines", body: empty });
  const [lead, ...rest] = items;
  const sections = ["pakistan", "islamabad", "world", "business", "sports"].map(c => {
    const l = by(items, c).slice(0, 4); if (!l.length) return "";
    return `<section><h2 class="sec">${CATS[c][1]}</h2><div class="cards">${l.map(card).join("")}</div><a class="more" href="/${c}">More ${CATS[c][0]} news</a></section>`;
  }).join("");
  const body = `<div class="grid"><div><section class="hero">${a(lead)}${pic(lead)}</a><h2>${a(lead)}${esc(lead.title)}</a></h2><p>${esc(lead.desc)}</p>${meta(lead)}</section>
<h2 class="sec">Top stories</h2>${rest.slice(0, 5).map(row).join("")}</div>
<aside class="side"><h2>Latest updates</h2><ul>${rest.slice(5, 15).map(i => `<li>${a(i)}${esc(i.title)}</a>${meta(i)}</li>`).join("")}</ul></aside></div>${sections}`;
  return shell({ path: "/", title: "Voxora News | Pakistan Live News & World Headlines", desc: "Read the latest Pakistan news, Islamabad updates, world headlines, business and sports on Voxora News, refreshed through the day.", h1: "Pakistan Live News and World Headlines", sub: "Breaking news from Pakistan, Islamabad and the world, updated through the day.", body, items });
}

function category(c, items) {
  const [label, h1, title, desc] = CATS[c], l = by(items, c).slice(0, 30);
  return shell({ path: "/" + c, title, desc, h1, sub: desc, items: l, body: l.length ? `<section>${l.map(row).join("")}</section>` : empty });
}

const html = (b, ok = true, type = "text/html; charset=utf-8") => new Response(b, { headers: { "content-type": type,
  "cache-control": ok ? "public, max-age=120, s-maxage=600" : "public, max-age=15, s-maxage=30" } });
const toItem = x => ({ own: true, cat: x.category || "pakistan", src: "Voxora News", img: x.image, title: x.title, link: "/news/" + x.slug, slug: x.slug, desc: x.summary || "", body: x.body || "", date: new Date(x.date) });

function article(x) {
  const label = (CATS[x.cat] || CATS.pakistan)[0], path = "/news/" + x.slug;
  const ld = { "@context": "https://schema.org", "@type": "NewsArticle", headline: x.title, datePublished: x.date.toISOString(), dateModified: x.date.toISOString(),
    ...(x.img ? { image: [x.img] } : {}), mainEntityOfPage: SITE + path, author: { "@type": "Organization", name: NAME }, publisher: { "@type": "Organization", name: NAME, logo: { "@type": "ImageObject", url: SITE + "/favicon.svg" } } };
  const paras = x.body.split(/\n\s*\n/).filter(t => t.trim()).map(t => `<p>${esc(t.trim())}</p>`).join("");
  return shell({ path, title: `${x.title} | ${NAME}`, desc: (x.desc || x.body).slice(0, 155), image: x.img, extra: [ld],
    body: `<article class="page"><p class="meta"><b>${label}</b><time datetime="${x.date.toISOString()}">${when(x.date)}</time></p><h1>${esc(x.title)}</h1>${x.img ? `<img src="${esc(x.img)}" alt="${esc(x.title)}" width="1200" height="675">` : ""}${paras}<a class="more" href="/${x.cat}">More ${label} news</a></article>` });
}

async function render(req, env) {
  const u = new URL(req.url), p = u.pathname.replace(/\/+$/, "") || "/", k = p.slice(1);
  let mine = [];
  try { mine = (await (await env.ASSETS.fetch(new URL("/articles.json", u))).json()).map(toItem).filter(x => x.slug && x.title && !isNaN(x.date)); } catch {}
  if (p === "/sitemap.xml") {
    const now = new Date().toISOString(), urls = ["/", ...Object.keys(CATS).map(c => "/" + c), "/about", "/contact", "/privacy"].map(x => [x, now]).concat(mine.map(m => [m.link, m.date.toISOString()]));
    return html(`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${urls.map(([x, d]) => `<url><loc>${SITE}${x}</loc><lastmod>${d}</lastmod></url>`).join("")}</urlset>`, true, "application/xml");
  }
  if (STATIC[k]) return html(shell({ path: p, title: `${STATIC[k][0]} | ${NAME}`, desc: STATIC[k][1].slice(0, 155), body: `<section class="page"><h1>${STATIC[k][0]}</h1><p>${STATIC[k][1]}</p></section>` }));
  if (k === "contact") return html(shell({ path: p, title: `Contact Us | ${NAME}`, desc: "Send a news tip or story idea to the Voxora News team by email or WhatsApp.",
    body: `<section class="page"><h1>Contact us</h1><p>Have a news tip, a story idea, or a question? Write to us or call us.</p>
<div class="card"><b>Email</b><a href="mailto:faixxaankhan786@gmail.com">faixxaankhan786@gmail.com</a></div>
<div class="card"><b>Phone and WhatsApp</b><a href="tel:+923336146497">+92 333 6146497</a> &nbsp; <a href="https://wa.me/923336146497">Message on WhatsApp</a></div></section>` }));
  if (k.startsWith("news/")) { const x = mine.find(m => m.link === "/" + k); return x ? html(article(x)) : new Response("Not found", { status: 404 }); }
  if (p !== "/" && !CATS[k]) return new Response("Not found", { status: 404 });
  const items = await load(mine);
  return html(p === "/" ? home(items) : category(k, items), items.length > 0);
}

export async function onRequest({ request, env, waitUntil }) {
  const u = new URL(request.url);
  if (u.hostname.startsWith("www.")) { u.hostname = u.hostname.slice(4); return Response.redirect(u.toString(), 301); }
  if (request.method !== "GET") return new Response("Method not allowed", { status: 405 });
  const hit = await caches.default.match(request);
  if (hit) return hit;
  const res = await render(request, env);
  if ((res.headers.get("cache-control") || "").includes("s-maxage=600")) waitUntil(caches.default.put(request, res.clone()));
  return res;
}
