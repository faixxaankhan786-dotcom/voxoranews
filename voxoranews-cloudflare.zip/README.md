# Voxora News (Cloudflare Pages)
Build command: (empty)   Output directory: public   Framework: None

## Apni khabar daalna
1. GitHub par `public/articles.json` kholein, pencil (Edit) dabayein.
2. `articles.example.json` jaisi entry `[ ]` ke andar paste karein (entries ke beech comma).
3. Commit karein. 1 se 2 minute mein khabar live hai: voxoranews.com/news/<slug>
category: pakistan, islamabad, world, business, sports. date mein hamesha +05:00 likhein.
Title/heading badalne ke liye `functions/[[path]].js` mein CATS dekhein.
RSS feeds badalne ke liye usi file mein FEEDS.
